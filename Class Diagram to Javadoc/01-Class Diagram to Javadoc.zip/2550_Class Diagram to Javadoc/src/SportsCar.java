
/** 
 * SportsCar
 * Created Jan, 17, 2013
 * @author Boris Jurosevic
 * CS 2550 Class diagram to JavaDoc
 */

/**
 *this is public interface sportscar
 */
public interface SportsCar {
	
	/**
	 * this is a press clutch method that is used in car class
	 */
	public void PressClutch();
	/**
	 * this is a usenitro method that is used in car class
	 */
	public void UseNitro();

}

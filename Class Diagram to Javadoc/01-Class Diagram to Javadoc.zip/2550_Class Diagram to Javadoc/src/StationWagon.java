
/** 
 * StationWagon
 * Created Jan, 17, 2013
 * @author Boris Jurosevic
 * CS 2550 Class diagram to JavaDoc
 */

/**
 * this is public interface stationwagon
 */
public interface StationWagon {
	
	/**
	 * this is a opentaligate method that is used in a car class
	 */
	public void OpenTaligate();

}

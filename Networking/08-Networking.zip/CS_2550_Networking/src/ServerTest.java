/**
 *  Boris Jurosevic
 *  CS 2550
 *  Assignment Networking
 */

public class ServerTest
{
   public static void main( String args[] )
   {
      Server application = new Server(); // create server application
      application.runServer(); // run server
   } 
} 
